#######################################################################
#Import Modules and or Scripts
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import os
#######################################################################

#######################################################################
#You can change the colors of your wizard text here. 
#Please do not edit # or change COLOR2 or it will break all the colors 
# in the entire wizard!
# For a complete list of colors available please visit
# http://forum.kodi.tv/showthread.php?tid=210837
COLOR               = '[COLOR green][B]'
COLOR1              = '[COLOR snow][B]'
COLOR2              = '[/B][/COLOR]'
COLOR3              = '[COLOR crimson][B]'
COLOR4              = '[COLOR springgreen][B]'
#######################################################################
#Editable Global Variables and Notification Settings
#######################################################################
#This should MATCH your plugin name exactly.
AddonID             = 'plugin.program.TWOinONE'
#######################################################################
#This is the URL to the directory where your .txt and .xml files are
#located on your host.
#IMPORTANT DO NOT ADD THE / AT THE END OF YOUR URL OR YOUR WIZARD
#WILL NOT WORK. IT HAS BEEN CODED TO ADD THE / ITSELF!!!!!!!!!!!!!!!!
#CORRECT WORKING EXAMPLE: 'http://vampinc.com/tksapps'
#BAD NON WORKING EXAMPLE: 'http://vampinc.com/tksapps/'
URL                 = 'http://kodi.sinners-city.com/docs/'
#######################################################################
#Set your Title here example: 'Bootson's Applications for Kodi: Wizard'
ADDONTITLE          = 'Bootson\'s Applications for Kodi: Wizard'
#######################################################################
#This is the "folder" that your files are located in on your host. So if
#your url is http://yoururlhere.com/tksapps/ then the PATH is tksapps.
PATH                = "Docs"
#######################################################################
#EXCLUDES Section - You can add your repo or other addons here.
EXCLUDES            = [AddonID,'script.module.requests','temp','backupdir']
#######################################################################
#You can change this to match your wizard name if you would like. 
#Please be sure to leave a space after the same before the ' at the end.
GROUP_NAME          = 'Bootson\'s Applications for Kodi: '
#######################################################################
#How often you would list it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK         = 0
#######################################################################
#AUTO UPDATE - You do NOT need a REPOSITORY with this Wizard
#Enable Auto Update 'Yes' or 'No'
AUTOUPDATE          = 'Yes'
#######################################################################
#DO NOT EDIT THIS LINE PLEASE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
BASEURL             = URL + '/'
#######################################################################
#Wizard Version text file
WIZVER              = BASEURL + 'wizver.txt'
#######################################################################                                                          
#Adult Wizard text file
ADULTFILE           = BASEURL + 'adult.txt'
#######################################################################
#APK text file
APKFILE             = BASEURL + 'apk.txt'
#######################################################################
#Notification text file
NOTIFICATION        = BASEURL + 'notify.txt'
#######################################################################
#Support Wizard text file
SUPPORT             = BASEURL + 'support.txt'
#######################################################################
#Theme Wizard text file
THEMEFILE           = BASEURL + 'themes.txt'
#######################################################################
#Version text file / Be sure you have the same version text file inside
#your userdata folder. This is required for the version check to work!
VERSION             = BASEURL + 'version.txt'
#######################################################################
#Wizard text file
WIZARDFILE          = BASEURL + 'wizard.txt'
#######################################################################
#Background for Notification Window
BACKGROUND          = BASEURL + 'bg.png'
#######################################################################
#Notification Button One 
BUTTON1             = BASEURL + 'b1.png'
#######################################################################
#Notification Button Two
BUTTON2             = BASEURL + 'b2.png'
#######################################################################
#Background for Notification Window
WINDOW              = BASEURL + 'bg.png'
#######################################################################
# Enable Notification screen Yes or No
ENABLE              = 'Yes'
#######################################################################
#Notification Text Color, Please only change the COLORNAME
COLORNAME           = 'snow'
#######################################################################
#Please do not change the code for THEME or it will have an impact
#on how your text is displayed in the notification windows.
THEME1              = '[COLOR '+COLORNAME+'][B]%s[/B][/COLOR]'  
#######################################################################
# Use either 'Text' or 'Image'
HEADERTYPE          = 'Text'
#######################################################################
# Font size of header
FONTHEADER          = 'Font14'
#######################################################################
# url to image if using Image 424x180
HEADERIMAGE         = ''
#######################################################################
# Font for Notification Window
FONTSETTINGS        = 'Font12'
#######################################################################
# Background for Notification Window
BACKGROUND          = ''
#######################################################################
#Menu Names are controlled here
ADULT               = 'Adults Builds Menu'
APKNAME             = 'APK Installer'
BACKUPBUILD         = 'Backup Build (Exc: Databases & Thumbnails)'
BACKUPLOGIN         = 'Backup Login Data'
BUILD               = 'Builds Menu'
CHKREPO             = 'Check for Broken Repositories'
CHKSOURCE           = 'Check for Broken Sources'
CLEARCACHE          = 'Clear Cache'
CLEARPACK           = 'Clear Packages'
CLEARTHUMB          = 'Clear Thumbnails'
CONVERT             = 'Convert Paths to Special'
DELETEALL           = 'Delete All Backups'
DELETEBACKUP        = 'Delete A Backup'
DEV                 = 'Developer Menu'
FRESHSTART          = 'Fresh Start'
MAINT               = 'Maintenance Menu'
REST                = 'Restore Data'
RESTOREBUILDBCK     = 'Restore Build Backup'
RESTORELOGIN        = 'Restore Login Data'
SAVE                = 'Save Data'
THEME               = 'Theme Menu'
VIEW                = 'View Kodi Log'
#######################################################################
#Please do not change the the code for ART as this will affect all images!
ART                 = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID, 'resources/art/'))
#######################################################################

#######################################################################
#Image ICON's are set below
ADULT_ICON          = ART + 'adult.png'
APK_ICON            = ART + 'apk.png'
BACKUP_ICON         = ART + 'backupbuild.png'
BACKUPLOGIN_ICON    = ART + 'backuplogin.png'
BUILDS_ICON			= ART + 'builds.png'
CACHE_ICON          = ART + 'cache.png'
CHKREPO_ICON        = ART + 'repo.png'
CHKSOURCE_ICON      = ART + 'source.png'
CONVERTPATH_ICON    = ART + 'convert.png'
CREDIT_ICON         = ART + 'credits.png'
DELETEALL_ICON      = ART + 'deleteallbackups.png'
DELETEBACKUP_ICON   = ART + 'deletebackup.png'
DEV_ICON            = ART + 'developer.png'
FANART              = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID , 'fanart.jpg'))
FRESHSTART_ICON     = ART + 'freshstart.png'
ICON                = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID, 'icon.png'))
ICONSAVE            = ART + 'iconsave.png'
MAINT_ICON          = ART + 'maintenance.png'
PACKAGES_ICON       = ART + 'packages.png'
REST_ICON           = ART + 'restoredata.png'
RESTOREBACKUP_ICON  = ART + 'restorebackup.png'
RESTORELOGIN_ICON   = ART + 'restorelogin.png'
SAVE_ICON           = ART + 'save.png'
SUPPORT_ICON        = ART + 'contact.png'
THEME_ICON          = ART + 'themes.png'
THUMBNAILS_ICON     = ART + 'thumbnails.png'
VIEWLOG_ICON        = ART + 'viewlog.png'
#######################################################################

#######################################################################
#Global Variables
#Do Not Edit These Variables or any others in this wizard!
#######################################################################
ADDON               = xbmcaddon.Addon(id=AddonID)
HOME                = xbmc.translatePath('special://home/')
ADDONS              = os.path.join(HOME,      'addons')
USERDATA            = os.path.join(HOME,      'userdata')
ADDON_DATA          = xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDON_ID            = xbmcaddon.Addon().getAddonInfo('id')
ADDONDATA           = os.path.join(USERDATA,  'addon_data', ADDON_ID)
DATABASE            = os.path.join(USERDATA,  'Database') 
DATABASES           = xbmc.translatePath(os.path.join(USERDATA,'Database'))
dialog              = xbmcgui.Dialog()
DIALOG              = xbmcgui.Dialog()
dp                  = xbmcgui.DialogProgress()
DP                  = xbmcgui.DialogProgress()
EXCLUDES_FOLDER     = xbmc.translatePath(os.path.join(USERDATA,'BACKUP'))
HEADERMESSAGE       = GROUP_NAME
LOG                 = xbmc.translatePath('special://logpath/')
NAVI                = xbmc.translatePath(os.path.join(ADDONS,'script.navi-x'))
PACKAGES            = xbmc.translatePath(os.path.join('special://home/addons/' + 'packages'))
PLUGIN              = os.path.join(ADDONS,    ADDON_ID)
selfAddon           = xbmcaddon.Addon(id=AddonID)
skin                = xbmc.getSkinDir()
THUMBS              = os.path.join(USERDATA,  'Thumbnails')
USER_AGENT          = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
USB                 = xbmc.translatePath(os.path.join(HOME,'backupdir'))
#######################################################################